package models;

public interface Repair {
}
