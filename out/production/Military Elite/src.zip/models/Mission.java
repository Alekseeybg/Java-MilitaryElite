package models;

public interface Mission {
    void completeMission();
}
