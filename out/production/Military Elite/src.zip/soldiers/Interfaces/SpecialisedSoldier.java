package soldiers.Interfaces;

public interface SpecialisedSoldier {
    enum corps{
        Airforces,
        Marines
    }
}
