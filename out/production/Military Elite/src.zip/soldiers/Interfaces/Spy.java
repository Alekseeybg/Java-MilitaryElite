package soldiers.Interfaces;

public interface Spy extends Soldier {
    String getCodeNumber();
}
